package test1.com;

public class Throwskey {
	 public static void name()
	 {
		    throw new ArithmeticException("Try to divide by 0");
		  }

		  public static void main(String[] args) {
		    name();
		  }
		}



