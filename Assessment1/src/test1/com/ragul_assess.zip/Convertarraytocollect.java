package test1.com;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Convertarraytocollect {

	public static void main(String[] args) {
		
		 {
		        String countryArray[]= {"sam","tom","viki"};
		    
		        List countryList = Arrays.asList(countryArray);
		        System.out.println("collection ele "
		                           + countryList);
		    }
		}
		    }
		    

	


