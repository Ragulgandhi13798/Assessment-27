package test1.com;

import java.time.LocalDateTime;

public class Javadate {

	public static void main(String[] args) {
		
		 LocalDateTime t = LocalDateTime.now();
		 System.out.println(t);
	}

}
